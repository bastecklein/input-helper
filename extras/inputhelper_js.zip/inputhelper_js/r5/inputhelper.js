(function() {
    const HELPER_REVISION = "20230614";

    if(!window.apeApps) {
        window.apeApps = {};
    }

    if(!window.apeApps.utilities) {
        window.apeApps.utilities = {};
    }

    window.apeApps.utilities.inputHelper = {};

    window.apeApps.utilities.inputHelper.handleInput = handleInput;

    window.apeApps.utilities.inputHelper.getRevision = function() {
        return HELPER_REVISION;
    };

    function handleInput(object,downFunction,moveFunction,endFunction) {
        
        object.addEventListener("contextmenu",function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        object.addEventListener("ontouchforcechange",function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        object.touchAction = "none";
        object.contentZooming = "none";
        object.msTouchAction = "none";
        object.msContentZooming = "none";
            
        object.style.touchAction = "none";

        object.addEventListener("pointerdown", function (event) {
            event.preventDefault();
                
            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            downFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which
            );

            return false;
        },false);

        object.addEventListener("pointermove", function (event) {
            event.preventDefault();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            moveFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which
            );

            return false;
        },false);

        object.addEventListener("pointerout", function (event) {

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            endFunction(object, event.pointerId, pointerType, which);
            return false;
        },false);

        object.addEventListener("pointerup", function (event) {

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            endFunction(object, event.pointerId, pointerType, which);
            return false;
        },false);
        
    }
})();