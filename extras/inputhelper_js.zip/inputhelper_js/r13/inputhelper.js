(function() {
    const HELPER_REVISION = "20240813";

    if(!window.apeApps) {
        window.apeApps = {};
    }

    if(!window.apeApps.utilities) {
        window.apeApps.utilities = {};
    }

    window.apeApps.utilities.inputHelper = {};

    window.apeApps.utilities.inputHelper.handleInput = handleInput;
    window.apeApps.utilities.inputHelper.clickAndContextHelper = clickAndContextHelper;
    window.apeApps.utilities.inputHelper.clearElementForTouch = clearElementForTouch;

    window.apeApps.utilities.inputHelper.getRevision = function() {
        return HELPER_REVISION;
    };

    let iOSHoldItem = null;
    let iostouchhold = null;

    function clearElementForTouch(object) {
        object.addEventListener("contextmenu", function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        }, { passive: false });

        object.addEventListener("ontouchforcechange",function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        }, { passive: false });

        object.addEventListener("webkitmouseforcewillbegin",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforcedown",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforceup",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforcechanged",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        

        object.touchAction = "none";
        object.contentZooming = "none";
        object.msTouchAction = "none";
        object.msContentZooming = "none";
            
        object.style.touchAction = "none";
        object.style.userSelect = "none";
    }

    function handleInput(object, downFunction, moveFunction, endFunction, ignoreOut = false) {
        
        clearElementForTouch(object);

        object.addEventListener("touchstart",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("pointerdown", function (event) {
            event.preventDefault();
            event.stopPropagation();
                
            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            downFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which,
                event.pageX,
                event.pageY
            );

            return false;
        }, { passive: false });

        object.addEventListener("pointermove", function (event) {
            event.preventDefault();
            event.stopPropagation();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            moveFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which,
                event.pageX,
                event.pageY
            );

            return false;
        }, { passive: false });

        if(!ignoreOut) {
            object.addEventListener("pointerout", function (event) {

                event.preventDefault();
                event.stopPropagation();
    
                let pointerType = "mouse";
                    
                if (event.pointerType) {
                    pointerType = event.pointerType;
                }
    
                let which = 1;
                    
                if(pointerType == "mouse") {
                    if(event.which) {
                        which = event.which;
                    }
                }
    
                endFunction(object, event.pointerId, pointerType, which, "out");
                return false;
            }, { passive: false });
        }
        

        object.addEventListener("pointerup", function (event) {

            event.preventDefault();
            event.stopPropagation();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            endFunction(object, event.pointerId, pointerType, which, "up");
            return false;
        }, { passive: false });
        
    }

    function clickAndContextHelper(element, funClick, funContext, aalInstance) {

        if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {

            let touchStatus = null;

            element.ontouchstart = function(e) {
                e.preventDefault();
                e.stopPropagation();

                touchStatus = "down";

                iOSHoldItem = element;

                iostouchhold = setTimeout(function() {

                    if(iOSHoldItem != null) {
                        iOSHoldItem.touchStatus = "up";
                    
                        if(!aalInstance || !aalInstance.isTV) {

                            if(navigator.vibrate) {
                                navigator.vibrate(100);
                            }

                            funContext(element, e.pageX, e.pageY);
                        }
                    }

                    killIosHold();

                
                },600);
            };

            element.ontouchend = function(e) {

                e.preventDefault();
                e.stopPropagation();

                const stat = touchStatus;

                touchStatus = "up";

                killIosHold();

                if(stat == "down") {
                    let useEle = element;

                    if(e.target) {
                        useEle = e.target;
                    }
                    
                    funClick(useEle, e.pageX, e.pageY);
                }

            };

            element.ontouchcancel = function(e) {

                e.preventDefault();
                e.stopPropagation();

                touchStatus = "up";
                killIosHold();
            };

        
            element.ontouchmove = function(e) {

                e.preventDefault();
                e.stopPropagation();

                touchStatus = "up";
                killIosHold();
            };
        } else {
            element.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                let useEle = element;

                if(e.target) {
                    useEle = e.target;
                }

                funClick(useEle, e.pageX, e.pageY);
            };

            element.oncontextmenu = function(e) {
                e.preventDefault();
                e.stopPropagation();

                if(navigator.vibrate) {
                    navigator.vibrate(50);
                }

                funContext(element, e.clientX, e.clientY);
            };
        }
    }

    function killIosHold() {
        if(iostouchhold != null) {
            clearTimeout(iostouchhold);
        }

        iOSHoldItem = null;
        iostouchhold = null;
    }
})();