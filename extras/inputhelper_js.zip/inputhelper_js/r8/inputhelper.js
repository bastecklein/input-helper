(function() {
    const HELPER_REVISION = "20240224";

    if(!window.apeApps) {
        window.apeApps = {};
    }

    if(!window.apeApps.utilities) {
        window.apeApps.utilities = {};
    }

    window.apeApps.utilities.inputHelper = {};

    window.apeApps.utilities.inputHelper.handleInput = handleInput;

    window.apeApps.utilities.inputHelper.getRevision = function() {
        return HELPER_REVISION;
    };

    function handleInput(object,downFunction,moveFunction,endFunction) {
        
        object.addEventListener("contextmenu", function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        }, { passive: false });

        object.addEventListener("ontouchforcechange",function(e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        }, { passive: false });

        object.addEventListener("webkitmouseforcewillbegin",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforcedown",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforceup",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("webkitmouseforcechanged",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.addEventListener("touchstart",function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });

        object.touchAction = "none";
        object.contentZooming = "none";
        object.msTouchAction = "none";
        object.msContentZooming = "none";
            
        object.style.touchAction = "none";
        object.style.userSelect = "none";

        object.addEventListener("pointerdown", function (event) {
            event.preventDefault();
            event.stopPropagation();
                
            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            downFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which
            );

            return false;
        }, { passive: false });

        object.addEventListener("pointermove", function (event) {
            event.preventDefault();
            event.stopPropagation();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }
                
            let pressure = 1;
                
            if (event.pressure) {
                pressure = event.pressure;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            moveFunction(
                object, 
                event.pointerId, 
                event.offsetX, 
                event.offsetY, 
                pointerType, 
                pressure,
                which
            );

            return false;
        }, { passive: false });

        object.addEventListener("pointerout", function (event) {

            event.preventDefault();
            event.stopPropagation();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            endFunction(object, event.pointerId, pointerType, which);
            return false;
        }, { passive: false });

        object.addEventListener("pointerup", function (event) {

            event.preventDefault();
            event.stopPropagation();

            let pointerType = "mouse";
                
            if (event.pointerType) {
                pointerType = event.pointerType;
            }

            let which = 1;
                
            if(pointerType == "mouse") {
                if(event.which) {
                    which = event.which;
                }
            }

            endFunction(object, event.pointerId, pointerType, which);
            return false;
        }, { passive: false });
        
    }
})();